# Kanban-HTML-CSS-JavaScript

### Tablero de tareas (Kanban) creado con HTML, CSS y JavaScript
