from django.contrib import admin

from .models import Proyecto, Tarea

def ver_tablero(modeladmin, request, queryset):
    for proyecto in queryset:
        # Recuperar todas las tareas relacionadas con el proyecto seleccionado
        tareas_del_proyecto = Tarea.objects.filter(proyecto=proyecto)

    for tarea in tareas_del_proyecto:
        print(tarea.nombre)
   
@admin.register(Proyecto)
class ProyectoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'fecha_creacion')
    list_filter = ('fecha_creacion',)
    search_fields = ('nombre', 'descripcion')
    actions = [ver_tablero]  # Agregar la acción personalizada


@admin.register(Tarea)
class TareaAdmin(admin.ModelAdmin):
    list_display = ('nombre','estado','proyecto', 'fecha_creacion', 'completada')
    list_filter = ('proyecto', 'completada')
    search_fields = ('nombre', 'descripcion')
# Register your models here.


