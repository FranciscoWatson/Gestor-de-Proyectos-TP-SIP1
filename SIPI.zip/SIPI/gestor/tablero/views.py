from django.shortcuts import render

def ver_tablero(request):
    # Aquí puedes realizar cualquier lógica que necesites para cargar los datos del tablero
    # Por ejemplo, recuperar las tareas relacionadas con el proyecto

    # Luego, renderiza el template "tablero.html" con los datos
    return render(request, 'index.html')
